
<img src="{{url('img/telkom.png')}}" alt="logo" {{ $attributes }} >
