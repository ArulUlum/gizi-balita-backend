<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      <?php echo e(__('Data Anak')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 bg-white border-b border-gray-200">
          <div class="w-full text-center">
            <h3 class="font-bold mb-4">Statistik Keseluruhan</h3>
            <div class="flex w-full justify-center mb-5">
              <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statistik => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center mx-5">
                  <h3 class="font-medium"><?php echo e(str_replace('_', ' ', strtoupper($statistik))); ?></h3>
                  <table class="w-full text-sm text-left text-gray-500">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                      <tr>
                        <th scope="col" class="px-6 py-3">
                          Kategori
                        </th>
                        <th scope="col" class="px-6 py-3">
                          Total
                        </th>
                      </tr>
                    </thead>
                    <tbody>

                      <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-white border-b text-gray-900 ">
                          <td class="px-6 py-4">
                            <?php echo e(str_replace('_', ' ', strtoupper($kategori))); ?>

                          </td>
                          <td class="px-6 py-4 text-right">
                            <?php echo e($total); ?>

                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>

          <div class="relative overflow-x-auto shadow-md sm:rounded-lg">




            <table class="w-full text-sm text-left text-gray-500">
              <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    Nama
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Umur
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Berat Badan
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Tinggi
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Lingkar Kepala
                  </th>
                  <th scope="col" class="px-6 py-3">
                    <span class="sr-only">Detail</span>
                  </th>
                </tr>
              </thead>
              <tbody>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="bg-white border-b text-gray-900 ">
                    <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                      <?php echo e($anak->nama); ?>

                    </th>
                    <td class="px-6 py-4">
                      <?php echo e($anak->umur(now())); ?> bulan (<?php echo e($anak->tanggal_lahir); ?>)
                    </td>
                    <td class="px-6 py-4">
                      <?php echo e($anak->beratTerakhir()); ?> Kg
                    </td>
                    <td class="px-6 py-4">
                      <?php echo e($anak->tinggiTerakhir()); ?> Cm
                    </td>
                    </td>
                    <td class="px-6 py-4">
                      <?php echo e($anak->lingkarKepalaTerakhir()); ?>

                    </td>
                    <td class="px-6 py-4 text-right">
                      <a href="/detail-anak/<?php echo e($anak->id); ?>"
                        class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Detail</a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\pengabdian-masyarakat\gizi-balita-backend\resources\views/dashboard.blade.php ENDPATH**/ ?>