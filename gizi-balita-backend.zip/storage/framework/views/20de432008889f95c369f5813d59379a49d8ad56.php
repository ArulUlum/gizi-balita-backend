
<img src="<?php echo e(url('img/telkom.png')); ?>" alt="logo" <?php echo e($attributes); ?> >
<?php /**PATH D:\pengabdian-masyarakat\gizi-balita-backend\resources\views/components/application-logo.blade.php ENDPATH**/ ?>