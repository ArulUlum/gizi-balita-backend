# Peengmas Monitoring Stunting Telkom University

## RUN
- make dependecies:
    - `composer install` 
- set db migration 
    - `php artisan migrate`
- make ui dependencies 
    - `npm run prod` for production
    - `npm run dev` for development

